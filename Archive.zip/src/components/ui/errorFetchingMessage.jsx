import React from "react";

export default function ErrorFetchingMessage() {
  return <div>errorFetchingMessage</div>;
}
