"use client";
import { AddUsers } from "@/components/ui/addUsers";

export default function AddUser() {
  return (
    <div className="flex items-center justify-center p-24">
      <AddUsers />
    </div>
  );
}
