"use client";
import AddCatagoryForm from "@/components/ui/addCatagoryForm";

export default function AddCatagory() {
  return (
    <div className="flex items-center justify-center h-full w-full py-24">
      <AddCatagoryForm />
    </div>
  );
}
