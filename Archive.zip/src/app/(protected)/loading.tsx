"use client";
import Circleloading from "@/components/ui/circleloading";

export default function loading() {
  return <Circleloading />;
}
