"use client";
import AddProductForm from "@/components/ui/addProductForm";

export default function AddProduct() {
  return (
    <div className="flex items-center justify-center h-full w-full py-24">
      <AddProductForm />
    </div>
  );
}
