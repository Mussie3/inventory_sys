"use client";
import AddSalesForm from "@/components/ui/addSalesForm";

export default function AddSales() {
  return (
    <div className="flex items-center justify-center h-full w-full py-24">
      <AddSalesForm />
    </div>
  );
}
